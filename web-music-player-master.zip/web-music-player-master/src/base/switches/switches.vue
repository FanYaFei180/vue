<template>
  <ul class="switches">
    <li class="switch-item" v-for="(item,index) in switches" :class="{'active':currentIndex === index}" @click="switchItem(index)" :key="index">
      <span>{{item.name}} </span>
    </li>
  </ul>
</template>

<script type="text/ecmascript-6">
export default {
  props: {
    switches: {
      type: Array
      // default: []
    },
    currentIndex: {
      type: Number,
      default: 0
    }
  },
  methods: {
    switchItem(index) {
      this.$emit("switch", index);
    }
  }
};
</script>

<style scoped lang="scss">
@import "assets/css/mixin.scss";

.switches {
  display: flex;
  align-items: center;
  width: rem(240);
  margin: 0 auto;
  border: 1px solid #333;
  border-radius: 5px;
}
.switch-item {
  flex: 1;
  padding: rem(8);
  text-align: center;
  font-size: rem(14);
  color: hsla(0, 0%, 100%, 0.3);
}

.active {
  background: #333;
  color: #fff;
}
</style>
