package com.wm.remusic.json;

/**
 * Created by wm on 2016/4/15.
 */
public class GeDanSrcInfo {

    /**
     * listid : 6506
     * title : 只剩孤独 与我狂欢
     * pic_300 : http://c.hiphotos.baidu.com/ting/pic/item/63d0f703918fa0ece1dd6ea4219759ee3d6ddb05.jpg
     * pic_500 : http://a.hiphotos.baidu.com/ting/pic/item/09fa513d269759eed04a6a62b5fb43166d22df05.jpg
     * pic_w700 : http://c.hiphotos.baidu.com/ting/pic/item/6a63f6246b600c33846cd4611d4c510fd9f9a105.jpg
     * width : 375
     * height : 375
     * listenum : 53078
     * collectnum : 368
     * tag : 欧美,孤独,华语,夜晚
     * desc : 我们无法抗拒孤独。就好比是一次没有烟火的狂欢，但在心底迸射出的热情赤诚火热。时间，让我们体验过热闹，也让我们学会独处。
     * url : http://music.baidu.com/songlist/6506
     */

    private String listid;
    private String title;
    private String pic_300;
    private String pic_500;
    private String pic_w700;
    private String width;
    private String height;
    private String listenum;
    private String collectnum;
    private String tag;
    private String desc;
    private String url;

    public String getListid() {
        return listid;
    }

    public void setListid(String listid) {
        this.listid = listid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPic_300() {
        return pic_300;
    }

    public void setPic_300(String pic_300) {
        this.pic_300 = pic_300;
    }

    public String getPic_500() {
        return pic_500;
    }

    public void setPic_500(String pic_500) {
        this.pic_500 = pic_500;
    }

    public String getPic_w700() {
        return pic_w700;
    }

    public void setPic_w700(String pic_w700) {
        this.pic_w700 = pic_w700;
    }

    public String getWidth() {
        return width;
    }

    public void setWidth(String width) {
        this.width = width;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public String getListenum() {
        return listenum;
    }

    public void setListenum(String listenum) {
        this.listenum = listenum;
    }

    public String getCollectnum() {
        return collectnum;
    }

    public void setCollectnum(String collectnum) {
        this.collectnum = collectnum;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
