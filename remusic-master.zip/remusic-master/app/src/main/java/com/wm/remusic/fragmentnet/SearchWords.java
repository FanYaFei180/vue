package com.wm.remusic.fragmentnet;

/**
 * Created by wm on 2016/5/21.
 */
public interface SearchWords {
    void onSearch(String t);
}
