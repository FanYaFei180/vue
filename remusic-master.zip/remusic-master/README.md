# remusic
仿网易云音乐安卓版客户端

# screenshot
![](https://github.com/aa112901/remusic/blob/master/screenshot/1%20(2).png)
![](https://github.com/aa112901/remusic/blob/master/screenshot/device-2016-11-01-103226.png)
![](https://github.com/aa112901/remusic/blob/master/screenshot/1%20(3).png)
![](https://github.com/aa112901/remusic/blob/master/screenshot/device-2016-08-18-213206.png)
![](https://github.com/aa112901/remusic/blob/master/screenshot/device-2016-08-18-213321.png)
![](https://github.com/aa112901/remusic/blob/master/screenshot/1%20(5).png)
![](https://github.com/aa112901/remusic/blob/master/screenshot/1%20(6).png)
![](https://github.com/aa112901/remusic/blob/master/screenshot/1%20(7).png)
![](https://github.com/aa112901/remusic/blob/master/screenshot/1%20(9).png)
![](https://github.com/aa112901/remusic/blob/master/screenshot/1%20(10).png)
![](https://github.com/aa112901/remusic/blob/master/screenshot/device-2016-03-24-133544%20(%E5%A4%8D%E5%88%B6).png)
![](https://github.com/aa112901/remusic/blob/master/screenshot/device-2016-08-18-213609.png)
![](https://github.com/aa112901/remusic/blob/master/screenshot/play_change.png)
![](https://github.com/aa112901/remusic/blob/master/screenshot/device-2016-03-26-123242.png)
![](https://github.com/aa112901/remusic/blob/master/screenshot/device-2016-03-26-123513.png)
![](https://github.com/aa112901/remusic/blob/master/screenshot/device-2016-03-24-134324%20(%E5%A4%8D%E5%88%B6).png)
![](https://github.com/aa112901/remusic/blob/master/screenshot/locked.png)
![](https://github.com/aa112901/remusic/blob/master/screenshot/widget.png)


# Credits
- [Timber](https://github.com/naman14/Timber)
- [Fresco](https://github.com/facebook/fresco)
- [MediaPlayerProxy](https://github.com/andrewhanks/MediaPlayerProxy)
- [Android-ObservableScrollView](https://github.com/ksoichiro/Android-ObservableScrollView)
- [retrofit](https://github.com/square/retrofit)
- [ImitateNetEasyCloud](https://github.com/GiitSmile/ImitateNetEasyCloud)
- [okhttp](https://github.com/square/okhttp)
- [CustomLrcView](https://github.com/android-lili/CustomLrcView-master)
- [MagicaSakura](https://github.com/Bilibili/MagicaSakura "MagicaSakura")

# Change Log
## 2.6
- 加入开屏广告
- 修正动画和一些问题

## 1.6
- 加入桌面小部件
- 修正动画和一些问题

## 12.23
- 加入锁屏控制
- 其他

## 12.17
- 取消多任务下载，使用服务下载，增加下载通知
- 其他

## 11.17
- 增加本地歌曲侧边导航栏
- 修复播放的一些问题


## 11.1
- 增加主题换肤
- 其他

## 8.19 
- 增加歌词浏览，歌词调节歌曲播放进度
- 增加保存网络歌单到主页
- 其他
 
## 7.27
- 改动底部控制栏为fragment，设置activity跳转无动画，使底部控制栏看起来全局固定在底部
- 歌单列表使用Android-Observescrollview取代CollapsingToolbarLayout
- service支持在线歌曲播放，支持在线歌单，暂时在线歌曲不支持无缝播放
- 通过本地代理，增加在线歌曲缓存
- 布局的一些优化
- 修正主页刷新闪屏
- 其他